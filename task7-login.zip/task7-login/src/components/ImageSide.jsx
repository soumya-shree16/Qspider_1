import React from 'react'

const ImageSide = () => {
  return (
    <div className='image-container'>
        <img src="/developer.jpg" alt="img" />
    </div>
  )
}

export default ImageSide